#ifndef __USART5_H
#define __USART5_H

#include "stdio.h"	
#include "sys.h" 
#include "string.h" 


void uart5_init(u32 bound);

void uart5WriteBuf(uint8_t *buf, uint8_t len);

#endif

