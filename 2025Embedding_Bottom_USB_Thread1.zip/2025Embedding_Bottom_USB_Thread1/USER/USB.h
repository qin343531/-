#ifndef __USB_H
#define __USB_H
#include "stm32f4xx_conf.h"
#include "sys.h" 

void USBH_HID_Reconnect(void);
void USB_Connect(void);

#endif


