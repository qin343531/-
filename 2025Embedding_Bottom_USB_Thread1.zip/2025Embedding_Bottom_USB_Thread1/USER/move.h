#ifndef __MOVE_H
#define __MOVE_H
#include <sys.h>	 

void Speed_update_encoders(double Speed_Target);
void Speed_update_encoder(int i,double Speed_Target);
void Position_update_encoders(double Position_Target);
void Position_update_encoder(int i,double Position_Target);

void Angle_update(double Angle_Target); 


void Car_Forward(double Speed_Target);
void Car_Back(double Speed_Target);
void Car_Pan_Left(double Speed_Target);
void Car_Pan_Right(double Speed_Target);
void Car_Rotate_Left(double Speed_Target);
void Car_Rotate_Right(double Speed_Target);

void Car_Mode(double Target_Speed);

void drawcircle(float speedv,float R);


#endif
