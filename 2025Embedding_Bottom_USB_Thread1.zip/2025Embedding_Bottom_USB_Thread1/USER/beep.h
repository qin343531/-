#ifndef __USB_H
#define __USB_H
#include "stm32f4xx_conf.h"
#include "sys.h" 

void Beep_init(void);
void Beep_on(void);
void Beep_off(void);

#endif


