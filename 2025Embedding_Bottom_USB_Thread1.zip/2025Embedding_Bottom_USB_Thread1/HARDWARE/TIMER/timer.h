#ifndef __TIMER_H
#define __TIMER_H
#include <sys.h>	 
#include "stm32f4xx.h"
//#include "encoder.h"
#include "sys.h"
#include "stm32f4xx.h"  
void TIM9_Int_Init(u16 arr,u16 psc);
void TIM7_Int_Init(u16 arr,u16 psc);
void TIM6_Init(u16 arr,u16 psc);

void update_encoders(double Speed_Target);
void update_encoder(int i,double Speed_Target);

#endif
