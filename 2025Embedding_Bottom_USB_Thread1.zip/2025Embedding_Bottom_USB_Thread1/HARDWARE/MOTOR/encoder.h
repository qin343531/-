#ifndef __ENCODER_H
#define __ENCODER_H
#include <sys.h>	 

#define ENCODER_TIM_PERIOD (u16)(65535)   //���ɴ���65535 ��Ϊ��ʱ����16λ�ġ�

void Encoder_Init(void);

int Read_Encoder(u8 TIMX);

void TIM1_IRQHandler(void);
void TIM3_IRQHandler(void);
void TIM4_IRQHandler(void);
void TIM5_IRQHandler(void);

#endif
