#ifndef __DRIVE_H
#define __DRIVE_H
#include "sys.h"

void driveLF_Init(void);
void driveLB_Init(void);		
void driveRF_Init(void);
void driveRB_Init(void);	    
void controlLF_drive(int speed_pwm);
void controlLB_drive(int speed_pwm);
void controlRF_drive(int speed_pwm);
void controlRB_drive(int speed_pwm);

void Motor_Init(void);


#endif
