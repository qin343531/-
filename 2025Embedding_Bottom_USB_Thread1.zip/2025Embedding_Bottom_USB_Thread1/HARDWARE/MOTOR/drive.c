#include "drive.h" 

void driveLF_Init(void)
{    	 
	GPIO_InitTypeDef  GPIO_InitStructure;

	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOF, ENABLE);//ʹ��GPIOFʱ��

	//GPIOF9,F10��ʼ������
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4 | GPIO_Pin_5;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;//��ͨ���ģʽ
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;//�������
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;//100MHz
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;//����
	GPIO_Init(GPIOF, &GPIO_InitStructure);//��ʼ��
}

void driveLB_Init(void)
{    	 
	GPIO_InitTypeDef  GPIO_InitStructure;

	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOE, ENABLE);//ʹ��GPIOFʱ��

	//GPIOF9,F10��ʼ������
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2 | GPIO_Pin_3;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;//��ͨ���ģʽ
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;//�������
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;//100MHz
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;//����
	GPIO_Init(GPIOE, &GPIO_InitStructure);//��ʼ��	
}

void driveRF_Init(void)
{    	 
	GPIO_InitTypeDef  GPIO_InitStructure;

	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOG, ENABLE);//ʹ��GPIOFʱ��

	//GPIOF9,F10��ʼ������
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3 | GPIO_Pin_4;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;//��ͨ���ģʽ
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;//�������
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;//100MHz
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;//����
	GPIO_Init(GPIOG, &GPIO_InitStructure);//��ʼ��
}

void driveRB_Init(void)
{    	 
	GPIO_InitTypeDef  GPIO_InitStructure;

	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOG, ENABLE);//ʹ��GPIOFʱ��

	//GPIOF9,F10��ʼ������
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1 | GPIO_Pin_2;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;//��ͨ���ģʽ
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;//�������
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;//100MHz
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;//����
	GPIO_Init(GPIOG, &GPIO_InitStructure);//��ʼ��
}

void Motor_Init(void)
{
    driveLF_Init();
    driveLB_Init();
    driveRF_Init();
    driveRB_Init();
}

void controlLF_drive(int speed_pwm)
{
	if (speed_pwm<=0)
    {
        speed_pwm=-speed_pwm;
        GPIO_SetBits(GPIOF,GPIO_Pin_5);//5�ߵ�ƽ��4�ͷ�ת
        GPIO_ResetBits(GPIOF,GPIO_Pin_4);
        TIM_SetCompare1(TIM10,speed_pwm);
    }
	else if (speed_pwm>0)
    {
        GPIO_SetBits(GPIOF,GPIO_Pin_4);
        GPIO_ResetBits(GPIOF,GPIO_Pin_5);
        TIM_SetCompare1(TIM10,speed_pwm);
    }		
}

void controlLB_drive(int speed_pwm)
{
	if (speed_pwm<=0)
    {
        speed_pwm=-speed_pwm;
        GPIO_SetBits(GPIOE,GPIO_Pin_2);//5�ߵ�ƽ��4�ͷ�ת
        GPIO_ResetBits(GPIOE,GPIO_Pin_3);
        TIM_SetCompare1(TIM11,speed_pwm);
    }
	else if (speed_pwm>0)
    {
        GPIO_SetBits(GPIOE,GPIO_Pin_3);
        GPIO_ResetBits(GPIOE,GPIO_Pin_2);
        TIM_SetCompare1(TIM11,speed_pwm);
    }		
}


void controlRF_drive(int speed_pwm)
{	
    if (speed_pwm<=0)
    {
        speed_pwm=-speed_pwm;
        GPIO_SetBits(GPIOG,GPIO_Pin_3);//4�߷�ת
        GPIO_ResetBits(GPIOG,GPIO_Pin_4);//
        TIM_SetCompare3(TIM2,speed_pwm);
    }
    else if (speed_pwm>0)
    {
        GPIO_SetBits(GPIOG,GPIO_Pin_4);//5��4
        GPIO_ResetBits(GPIOG,GPIO_Pin_3);//
        TIM_SetCompare3(TIM2,speed_pwm);
    }		
}
	
void controlRB_drive(int speed_pwm)
{	
    if (speed_pwm<=0)
    {
        speed_pwm=-speed_pwm;
        GPIO_SetBits(GPIOG,GPIO_Pin_1);//4�߷�ת
        GPIO_ResetBits(GPIOG,GPIO_Pin_2);//
        TIM_SetCompare4(TIM2,speed_pwm);
    }
    else if (speed_pwm>0)
    {
        GPIO_SetBits(GPIOG,GPIO_Pin_2);//5��4
        GPIO_ResetBits(GPIOG,GPIO_Pin_1);//
        TIM_SetCompare4(TIM2,speed_pwm);
    }
    
}
				


