#ifndef __MOTOR_H
#define __MOTOR_H
#include <sys.h>	 

void TIM2_PWM_Init(u16 arr,u16 psc);
void TIM10_PWM_Init(u16 arr,u16 psc);
void TIM11_PWM_Init(u16 arr,u16 psc);

void Car_PWM_Init(u16 arr,u16 psc);

#endif
