#ifndef __LED_H
#define __LED_H
#include "sys.h"

void Driver_Init(void);
void LED_Init(void);//��ʼ��		
void LED_Toggle(void); 			
void LED2_ON(void);
void LED2_OFF(void);


#endif
